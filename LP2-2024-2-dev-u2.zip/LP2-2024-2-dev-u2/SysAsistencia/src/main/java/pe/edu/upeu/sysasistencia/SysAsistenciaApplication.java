package pe.edu.upeu.sysasistencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SysAsistenciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SysAsistenciaApplication.class, args);
	}

}
