package pe.edu.upeu.sysalmacen.repositorio;

import pe.edu.upeu.sysalmacen.modelo.Producto;

public interface IProductoRepository extends ICrudGenericoRepository<Producto, Long> {

}
