export const environment = {
  HOST:'http://localhost:8080',
};
